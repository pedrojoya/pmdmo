/** Automatically generated file. DO NOT MODIFY */
package es.iessaladillo.pedrojoya.pr022;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}